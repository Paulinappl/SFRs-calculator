# SFRs-calculator

This is a calculator to obtain SFRs.

Read the docs link: https://sfrs-calculator.readthedocs.io/en/latest/
