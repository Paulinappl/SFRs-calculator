# SFRs-calculator

This is a calculator to obtain SFRs. We use a random forest model trained with SFRS from the simulations of TNG ilustris.

Read the docs link: https://sfrs-calculator.readthedocs.io/en/latest/
